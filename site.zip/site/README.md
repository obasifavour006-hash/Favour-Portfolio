# Favour Obasi: Portfolio (static, GitHub Pages ready)
No build step. Plain HTML/CSS/JS with relative paths.

## Deploy
1. Create a GitHub repo, upload the *contents* of this folder (index.html at the repo root).
2. Settings → Pages → Source: "Deploy from a branch" → `main` / `(root)` → Save.
3. Site goes live at https://<username>.github.io/<repo>/ in about a minute.

## Edit
- Projects: `js/projects.js` (title, category, description). Add a video to `assets/videos/<id>.mp4` and a thumbnail `assets/images/poster-<id>.jpg`.
- Colours/fonts: CSS variables at top of `css/styles.css` (+ Google Fonts link in index.html).
- Social links: footer in `index.html` (replace the `#` hrefs).
- Tools list: `TOOLS` in `js/projects.js`.
